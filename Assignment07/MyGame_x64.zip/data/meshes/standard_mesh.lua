return
{
	vertexData = {0, 0, 0, 0.8, 0, 0, 0.8, 0.8, 0, 0, 0.8, 0},
	indexData = {0,1,2,0,2,3}
}

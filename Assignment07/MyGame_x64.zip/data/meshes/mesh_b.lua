return
{
	-- every three value in the vertexData array is a vertex data
	-- the vertex is in x, y, z order,
	vertexData = {
		0,		0,		0, 
		0.8,	0,		0, 
		0.8,	-0.8,	0, 
		0,		-0.8,	0
	},

	-- every three value in the indexData array are the vertex indexes of a triangle
	-- the vertices is in right-hand order,
	indexData = {
		0,	2,	1,
		0,	3,	2
	}
}

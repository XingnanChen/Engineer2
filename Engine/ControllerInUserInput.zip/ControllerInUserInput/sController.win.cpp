#include "sController.h"

#include "Engine/Logging/Logging.h"

// Static Data
//============

eae6320::sController eae6320::sController::g_controller;

void KeyState::UpdateKeyState(bool i_pressed)
{
	if (i_pressed)
	{
		b_first_released = false;
		b_prev_pressed = true;
	}
	else
	{
		if (b_prev_pressed)
			b_first_released = true;
		else
			b_first_released = false;

		b_prev_pressed = false;
	}
}

//BindActions for keyboard
void eae6320::sController::BindActions(uint_fast8_t i_key, eInputEvent i_inputEvent, std::function<void()> callback)
{
	get_registeredKeys().insert(i_key);
	get_keyStates()[i_key] = KeyState();
	switch (i_inputEvent)
	{
	case e_pressed:
	{
		get_pressedMapForKeyBoard()[i_key] = std::move(callback);
		break;
	}
	case e_released:
	{
		get_releasedMapForKeyboard()[i_key] = std::move(callback);
		break;
	}
	}
}

//BindActions for Gamepad buttons
void eae6320::sController::BindActions(UserInput::KeyCodes::eGamepadKeyCodes i_key, eInputEvent i_inputEvent, std::function<void()> callback)
{
	get_registeredKeysForGamepadButtons().insert(i_key);
	get_keyStatesForGamepadButtons()[i_key] = KeyState();
	switch (i_inputEvent)
	{
	case e_pressed:
	{
		get_pressedMapForGamepadButtons()[i_key] = std::move(callback);
		break;
	}
	case e_released:
	{
		get_releasedMapForGamepadButtons()[i_key] = std::move(callback);
		break;
	}
	}
}

//bind axis
void eae6320::sController::BindAxis(eae6320::UserInput::KeyCodes::eGamepadAxis i_key, std::function<void(float)> callback)
{
	get_registeredKeysForGamepadSticks().insert(i_key);
	get_mapForGamepadSticks()[i_key] = std::move(callback);
}

void eae6320::sController::TriggerActions()
{
	//According to the state of the key, trigger the binding action.
	//Keyboard
	XINPUT_STATE state;
	XInputGetState(0, &state);
	DWORD dwResult = XInputGetState(0, &state);
	if (dwResult == ERROR_SUCCESS)
	{
		//Gamepad Buttons:
		//According to the state of the key, trigger the binding action.
		UpdateGamepadButtonStates(state);
		for (auto& key : get_registeredKeysForGamepadButtons())
		{
			if (get_keyStatesForGamepadButtons()[key].b_prev_pressed)
			{
				if (get_pressedMapForGamepadButtons().find(key) != get_pressedMapForGamepadButtons().end())
					get_pressedMapForGamepadButtons()[key]();
			}
			if (get_keyStatesForGamepadButtons()[key].b_first_released)
			{
				if (get_releasedMapForGamepadButtons().find(key) != get_releasedMapForGamepadButtons().end())
					get_releasedMapForGamepadButtons()[key]();
			}
		}

		//Gamepad Sticks:
		//Left Stick:
		float LX = state.Gamepad.sThumbLX;
		float LY = state.Gamepad.sThumbLY;
		//Right Stick:
		float RX = state.Gamepad.sThumbRX;
		float RY = state.Gamepad.sThumbRY;
		for (auto& key : get_registeredKeysForGamepadSticks())
		{
			switch (key)
			{
			case UserInput::KeyCodes::GamepadLX:
			{
				float X = CalculateNormalizeMagnitude(LX, LY, XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE).X;
				get_mapForGamepadSticks()[key](X);
				break;
			}
			case UserInput::KeyCodes::GamepadLY:
			{
				float Y = CalculateNormalizeMagnitude(LX, LY, XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE).Y;
				get_mapForGamepadSticks()[key](Y);
				break;
			}
			case UserInput::KeyCodes::GamepadRX:
			{
				float X = CalculateNormalizeMagnitude(RX, RY, XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE).X;
				get_mapForGamepadSticks()[key](X);
				break;
			}
			case UserInput::KeyCodes::GamepadRY:
			{
				float Y = CalculateNormalizeMagnitude(RX, RY, XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE).Y;
				get_mapForGamepadSticks()[key](Y);
				break;
			}
			}
		}
	}
	
	//Keyboard:
	//Update the states of keys
	UpdateKeyboardKeyStates();

	for (auto& key : get_registeredKeys())
	{
		if (get_keyStates()[key].b_prev_pressed)
		{
			if (get_pressedMapForKeyBoard().find(key) != get_pressedMapForKeyBoard().end())
				get_pressedMapForKeyBoard()[key]();
		}
		if (get_keyStates()[key].b_first_released)
		{
			if (get_releasedMapForKeyboard().find(key) != get_releasedMapForKeyboard().end())
				get_releasedMapForKeyboard()[key]();
		}
	}
	
}

void eae6320::sController::UpdateKeyboardKeyStates()
{
	//Keyboard:
	for (auto& kv : get_keyStates())
	{
		kv.second.UpdateKeyState(eae6320::UserInput::IsKeyPressed(kv.first));
	}
}

void eae6320::sController::UpdateGamepadButtonStates(XINPUT_STATE i_state)
{
	//Gamepad Button
	
	// Controller is connected
	for (auto& kv : get_keyStatesForGamepadButtons())
	{
		kv.second.UpdateKeyState(i_state.Gamepad.wButtons & kv.first);
	}
}

//Keyboard
//Use to get_registeredKeys to save keys(for iterator)
std::set<uint_fast8_t>& eae6320::sController::get_registeredKeys()
{
	static std::set<uint_fast8_t> registeredKeys;
	return registeredKeys;
}

//Use to get_keyStates to save [keys, key states]
std::unordered_map<uint_fast8_t, KeyState>& eae6320::sController::get_keyStates()
{
	static std::unordered_map<uint_fast8_t, KeyState> keyStates;
	return keyStates;
}

//Use to get_pressedListiners to save [key, pressed call back function]
std::unordered_map<uint_fast8_t, std::function<void()>>& eae6320::sController::get_pressedMapForKeyBoard()
{
	static std::unordered_map<uint_fast8_t, std::function<void()>> pressedListeners;
	return pressedListeners;
}

//Use to get_pressedListiners to save [key, released call back function]
std::unordered_map<uint_fast8_t, std::function<void()>>& eae6320::sController::get_releasedMapForKeyboard()
{
	static std::unordered_map<uint_fast8_t, std::function<void()>> releasedListeners;
	return releasedListeners;
}

//Gamepad buttons
//Use to get_registeredKeys to save keys
std::set<WORD>& eae6320::sController::get_registeredKeysForGamepadButtons()
{
	static std::set<WORD> registeredKeys;
	return registeredKeys;
}

//Use to get_keyStates to save [keys, key states]
std::unordered_map<WORD, KeyState>& eae6320::sController::get_keyStatesForGamepadButtons()
{
	static std::unordered_map<WORD, KeyState> keyStates;
	return keyStates;
}

//Use to get_pressedListiners to save [key, pressed call back function]
std::unordered_map<WORD, std::function<void()>>& eae6320::sController::get_pressedMapForGamepadButtons()
{
	static std::unordered_map<WORD, std::function<void()>> pressedListeners;
	return pressedListeners;
}

//Use to get_pressedListiners to save [key, released call back function]
std::unordered_map<WORD, std::function<void()>>& eae6320::sController::get_releasedMapForGamepadButtons()
{
	static std::unordered_map<WORD, std::function<void()>> releasedListeners;
	return releasedListeners;
}

//Gamepad buttons
//Use to get_registeredKeys to save keys
std::set<WORD>& eae6320::sController::get_registeredKeysForGamepadSticks()
{
	static std::set<WORD> registeredKeys;
	return registeredKeys;
}

//Use to get_pressedListiners to save [key, pressed call back function]
std::unordered_map<WORD, std::function<void(float)>>& eae6320::sController::get_mapForGamepadSticks()
{
	static std::unordered_map<WORD, std::function<void(float)>> pressedListeners;
	return pressedListeners;
}

NormalizedXY eae6320::sController::CalculateNormalizeMagnitude(float X, float Y, float INPUT_DEADZONE)
{
	float magnitude = sqrt(X * X + Y * Y);

	//determine the direction the controller is pushed
	float normalizedLX = X / magnitude;
	float normalizedLY = Y / magnitude;

	float normalizedMagnitude = 0;

	//check if the controller is outside a circular dead zone
	if (magnitude > INPUT_DEADZONE)
	{
		//clip the magnitude at its expected maximum value
		if (magnitude > 32767) magnitude = 32767;

		//adjust magnitude relative to the end of the dead zone
		magnitude -= INPUT_DEADZONE;

		//optionally normalize the magnitude with respect to its expected range
		//giving a magnitude value of 0.0 to 1.0
		normalizedMagnitude = magnitude / (32767 - INPUT_DEADZONE);
	}
	else //if the controller is in the deadzone zero out the magnitude
	{
		magnitude = 0.0;
		normalizedMagnitude = 0.0;
	}
	NormalizedXY xy = { normalizedLX * normalizedMagnitude ,normalizedLY * normalizedMagnitude };
	Logging::OutputMessage("%f %f", xy.X, xy.Y);
	return xy;
}
Add sController.h into UserInput project
Add sController.win.cpp into UserInput project
Update UserInput.h in the UserInput project with UserInput.h
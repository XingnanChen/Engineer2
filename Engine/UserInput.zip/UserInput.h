/*
	This file provides an extremely basic interface for querying user input from the keyboard
*/

#ifndef EAE6320_USERINPUT_H
#define EAE6320_USERINPUT_H
#include <cstdint>

// Includes
//=========

// Interface
//==========

namespace eae6320
{
	namespace UserInput
	{
		
		namespace KeyCodes
		{
			// These values are what the Windows-specific function expects, for simplicity
			enum eKeyCodes
			{
				Left = 0x25,
				Up = 0x26,
				Right = 0x27,
				Down = 0x28,

				Space = 0x20,

				Escape = 0x1b,

				Shift = 0x10,
				Control = 0x11,
				Alt = 0x12,

				Tab = 0x09,
				CapsLock = 0x14,

				BackSpace = 0x08,
				Enter = 0x0d,
				Delete = 0x2e,

				PageUp = 0x21,
				PageDown = 0x22,
				End = 0x23,
				Home = 0x24,

				F1 = 0x70,
				F2 = 0x71,
				F3 = 0x72,
				F4 = 0x73,
				F5 = 0x74,
				F6 = 0x75,
				F7 = 0x76,
				F8 = 0x77,
				F9 = 0x78,
				F10 = 0x79,
				F11 = 0x7a,
				F12 = 0x7b,

				MouseLButton = 0x01,
				MouseRButton = 0x02,
			};
		
			//// Constants for gamepad buttons
			////
			//#define XINPUT_GAMEPAD_DPAD_UP          0x0001
			//#define XINPUT_GAMEPAD_DPAD_DOWN        0x0002
			//#define XINPUT_GAMEPAD_DPAD_LEFT        0x0004
			//#define XINPUT_GAMEPAD_DPAD_RIGHT       0x0008
			//#define XINPUT_GAMEPAD_START            0x0010
			//#define XINPUT_GAMEPAD_BACK             0x0020
			//#define XINPUT_GAMEPAD_LEFT_THUMB       0x0040
			//#define XINPUT_GAMEPAD_RIGHT_THUMB      0x0080
			//#define XINPUT_GAMEPAD_LEFT_SHOULDER    0x0100
			//#define XINPUT_GAMEPAD_RIGHT_SHOULDER   0x0200
			//#define XINPUT_GAMEPAD_A                0x1000
			//#define XINPUT_GAMEPAD_B                0x2000
			//#define XINPUT_GAMEPAD_X                0x4000
			//#define XINPUT_GAMEPAD_Y                0x8000
			enum eGamepadKeyCodes
			{
				A = 0x1000,
				B = 0x2000,
				X = 0x4000,
				Y = 0x8000,
				UP = 0x0001,
				DOWN = 0x0002,
				LEFT = 0x0004,
				RIGHT = 0x0008,
				START = 0x0010,
				BACK = 0x0020,
				LTHUMB = 0x0040,
				RTHUMB = 0x0080,
				LS = 0x0100,
				RS = 0x0200
			};

			enum eGamepadAxis
			{
				GamepadLX,
				GamepadLY,
				GamepadRX,
				GamepadRY
			};
		}

		
		// Returns if the specified key is currently pressed

		// For standard letter or number keys, the representative ascii char can be used:
		// IsKeyPressed( 'A' ) or IsKeyPressed( '6' )

		// For special keys use one of the KeyCodes enumerations below

		
		bool IsKeyPressed( const uint_fast8_t i_keyCode );

	}
}

#endif	// EAE6320_USERINPUT_H

#pragma once
#include <cstdint>
#include <map>
#include <set>
#include <Windows.h>
#include <functional>
#include "UserInput.h"


enum eInputEvent
{
	e_pressed,
	e_released
};


struct KeyState
{
	bool b_prev_pressed = false;

	//bool b_first_pressed = false;
	bool b_first_released = false;

	void UpdateKeyState(bool i_pressed);
	
};

struct NormalizedXY
{
	float X = 0.0f;
	float Y = 0.0f;
};

namespace eae6320
{
	struct sController
	{
		//BindActions are for key pressed and released
		//i_key		: the input key representation, the values are the same as they are in the windows 
		//i_inputEvent	: the key event representation, it only support two events now, e_pressed means key is pressed, e_released means the first time the key is released.
		//i_callback	: the callback function that will bind to the key.
		void BindActions(uint_fast8_t i_key, eInputEvent i_inputEvent, std::function<void()> callback);
		
		void BindActions(UserInput::KeyCodes::eGamepadKeyCodes i_key, eInputEvent i_inputEvent, std::function<void()> callback);

		//BindAxis allow for inputs that have a continuous range
		//i_key		: the input axis representation
		//i_callback	: the callback function that will bind to the axis.
		void BindAxis(UserInput::KeyCodes::eGamepadAxis i_key, std::function<void(float)> callback);

		//detect input and call the bind function
		void TriggerActions();

		//a static memeber, it is shared by all objects of the class. All static data is initialized to zero when the first object is created
		static sController g_controller;

	private:

		void UpdateKeyboardKeyStates();
		void UpdateGamepadButtonStates();

		
		static std::set<uint_fast8_t>& get_registeredKeys();

		static std::unordered_map<uint_fast8_t, KeyState>& get_keyStates();

		static std::unordered_map<uint_fast8_t, std::function<void()>>& get_pressedMapForKeyBoard();

		static std::unordered_map<uint_fast8_t, std::function<void()>>& get_releasedMapForKeyboard();

		static std::set<WORD>& get_registeredKeysForGamepadButtons();

		static std::unordered_map<WORD, KeyState>& get_keyStatesForGamepadButtons();

		static std::unordered_map<WORD, std::function<void()>>& get_pressedMapForGamepadButtons();

		static std::unordered_map<WORD, std::function<void()>>& get_releasedMapForGamepadButtons();

		static std::set<WORD>& get_registeredKeysForGamepadSticks();

		static std::unordered_map<WORD, std::function<void(float)>>& get_mapForGamepadSticks();

		NormalizedXY CalculateNormalizeMagnitude(float LX, float LY, float INPUT_DEADZONE);

	};
}


